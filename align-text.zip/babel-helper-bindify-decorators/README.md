# babel-helper-bindify-decorators

## Usage

TODO
