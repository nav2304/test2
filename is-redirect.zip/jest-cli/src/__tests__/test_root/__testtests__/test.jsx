// test.jsx

require('../module.jsx');
