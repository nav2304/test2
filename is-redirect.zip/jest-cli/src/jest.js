/**
 * Copyright (c) 2014, Facebook, Inc. All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */
'use strict';

const childProcess = require('child_process');
const fs = require('fs');
const path = require('path');
const TestRunner = require('./TestRunner');
const formatTestResults = require('./lib/formatTestResults');
const utils = require('./lib/utils');
const chalk = require('chalk');
const sane = require('sane');
const which = require('which');

const DEFAULT_WATCH_EXTENSIONS = 'js';
const WATCHER_DEBOUNCE = 200;
const WATCHMAN_BIN = 'watchman';

let jestVersion = null;
function getVersion() {
  if (jestVersion === null) {
    const packageJSON = path.resolve(__dirname, '..', 'package.json');
    jestVersion = require(packageJSON).version;
  }
  return jestVersion;
}

function findChangedFiles(dirPath) {
  return new Promise((resolve, reject) => {
    const args = ['diff', '--name-only', '--diff-filter=ACMR', '--relative'];
    const child = childProcess.spawn('git', args, {cwd: dirPath});

    let stdout = '';
    let stderr = '';
    child.stdout.on('data', data => stdout += data);
    child.stderr.on('data', data => stderr += data);
    child.on('close', code => {
      if (code === 0) {
        stdout = stdout.trim();
        if (stdout === '') {
          resolve([]);
        } else {
          resolve(stdout.split('\n').map(
            changedPath => path.resolve(dirPath, changedPath)
          ));
        }
      } else {
        reject(code + ': ' + stderr);
      }
    });
  });
}

function verifyIsGitRepository(dirPath) {
  return new Promise(resolve =>
    childProcess.spawn('git', ['rev-parse', '--git-dir'], {cwd: dirPath})
      .on('close', code => {
        const isGitRepo = code === 0;
        resolve(isGitRepo);
      })
  );
}

function testRunnerOptions(argv) {
  const options = {};
  if (argv.runInBand) {
    options.runInBand = argv.runInBand;
  }
  if (argv.maxWorkers) {
    options.maxWorkers = argv.maxWorkers;
  }
  return options;
}

function readConfig(argv, packageRoot) {
  return readRawConfig(argv, packageRoot).then(config => {
    if (argv.coverage) {
      config.collectCoverage = true;
    }

    if (argv.testEnvData) {
      config.testEnvData = argv.testEnvData;
    }

    config.noHighlight = argv.noHighlight || !process.stdout.isTTY;

    if (argv.verbose) {
      config.verbose = argv.verbose;
    }

    if (argv.bail) {
      config.bail = argv.bail;
    }

    if (argv.cache !== null) {
      config.cache = argv.cache;
    }

    if (argv.useStderr) {
      config.useStderr = argv.useStderr;
    }

    if (argv.json) {
      config.useStderr = true;
    }

    if (argv.testRunner) {
      try {
        config.testRunner = require.resolve(
          argv.testRunner.replace(/<rootDir>/g, config.rootDir)
        );
      } catch (e) {
        throw new Error(
          `jest: testRunner path "${argv.testRunner}" is not a valid path.`
        );
      }
    }

    if (argv.logHeapUsage) {
      config.logHeapUsage = argv.logHeapUsage;
    }

    config.noStackTrace = argv.noStackTrace;

    return config;
  });
}

function readRawConfig(argv, packageRoot) {
  if (typeof argv.config === 'string') {
    return utils.loadConfigFromFile(argv.config);
  }

  if (typeof argv.config === 'object') {
    return Promise.resolve(utils.normalizeConfig(argv.config));
  }

  const pkgJsonPath = path.join(packageRoot, 'package.json');
  const pkgJson = fs.existsSync(pkgJsonPath) ? require(pkgJsonPath) : {};

  // Look to see if there is a package.json file with a jest config in it
  if (pkgJson.jest) {
    if (!pkgJson.jest.hasOwnProperty('rootDir')) {
      pkgJson.jest.rootDir = packageRoot;
    } else {
      pkgJson.jest.rootDir = path.resolve(packageRoot, pkgJson.jest.rootDir);
    }
    const config = utils.normalizeConfig(pkgJson.jest);
    config.name = pkgJson.name;
    return Promise.resolve(config);
  }

  // Sane default config
  return Promise.resolve(utils.normalizeConfig({
    name: packageRoot.replace(/[/\\]/g, '_'),
    rootDir: packageRoot,
    testPathDirs: [packageRoot],
    testPathIgnorePatterns: ['/node_modules/.+'],
  }));
}

function findOnlyChangedTestPaths(testRunner, config) {
  const testPathDirsAreGit = config.testPathDirs.map(verifyIsGitRepository);
  return Promise.all(testPathDirsAreGit)
    .then(results => {
      if (!results.every(result => !!result)) {
        /* eslint-disable no-throw-literal */
        throw (
          'It appears that one of your testPathDirs does not exist ' +
          'with in a git repository. Currently --onlyChanged only works ' +
          'with git projects.\n'
        );
        /* eslint-enable no-throw-literal */
      }
      return Promise.all(config.testPathDirs.map(findChangedFiles));
    })
    .then(changedPathSets => {
      // Collapse changed files from each of the testPathDirs into a single list
      // of changed file paths
      let changedPaths = [];
      changedPathSets.forEach(
        pathSet => changedPaths = changedPaths.concat(pathSet)
      );
      return testRunner.promiseTestPathsRelatedTo(changedPaths);
    });
}

function buildTestPathPatternInfo(argv) {
  if (argv.testPathPattern) {
    return {
      input: argv.testPathPattern,
      pattern: argv.testPathPattern,
      shouldTreatInputAsPattern: true,
    };
  }
  if (argv._ && argv._.length) {
    return {
      input: argv._.join(' '),
      pattern: argv._.join('|'),
      shouldTreatInputAsPattern: false,
    };
  }
  return {
    input: '',
    pattern: '.*',
    shouldTreatInputAsPattern: false,
  };
}

function findMatchingTestPaths(pattern, testRunner) {
  return testRunner.promiseTestPathsMatching(new RegExp(pattern));
}


function getNoTestsFoundMessage(patternInfo) {
  const pattern = patternInfo.pattern;
  const input = patternInfo.input;
  const shouldTreatInputAsPattern = patternInfo.shouldTreatInputAsPattern;

  const formattedPattern = `/${pattern}/`;
  const formattedInput = shouldTreatInputAsPattern ?
    `/${input}/` :
    `"${input}"`;

  const message = `No tests found for ${formattedInput}.`;
  return input === pattern ?
    message :
    `${message} Regex used while searching: ${formattedPattern}.`;
}

/**
 * use watchman when possible
 */
function getWatcher(argv, packageRoot, callback) {
  which(WATCHMAN_BIN, function(err, resolvedPath) {
    const watchman = !err && resolvedPath;
    const watchExtensions = argv.watchExtensions || DEFAULT_WATCH_EXTENSIONS;
    const glob = watchExtensions.split(',').map(function(extension) {
      return '**/*' + extension;
    });
    const watcher = sane(packageRoot, {glob, watchman});
    callback(watcher);
  });
}

function runCLI(argv, packageRoot, onComplete) {
  argv = argv || {};

  if (argv.version) {
    console.log('v' + getVersion());
    onComplete && onComplete(true);
    return;
  }

  const pipe = argv.json ? process.stderr : process.stdout;

  function _runCLI(filePath) {
    readConfig(argv, packageRoot)
      .then(config => {
        // Disable colorization
        if (config.noHighlight) {
          chalk.enabled = false;
        }

        const testRunner = new TestRunner(config, testRunnerOptions(argv));
        const testFramework = require(config.testRunner);
        pipe.write(`Using Jest CLI v${getVersion()}, ${testFramework.name}\n`);

        let testPaths;
        if (argv.onlyChanged) {
          testPaths = findOnlyChangedTestPaths(testRunner, config);
        } else {
          const patternInfo = buildTestPathPatternInfo(argv);
          testPaths = findMatchingTestPaths(patternInfo.pattern, testRunner)
            .then(testPaths => {
              if (!testPaths.length) {
                pipe.write(`${getNoTestsFoundMessage(patternInfo)}\n`);
              }
              return testPaths;
            });
        }

        return testPaths.then(testPaths => {
          const shouldTest = !filePath || testPaths.some(testPath => {
            return testPath.indexOf(filePath) !== -1;
          });
          const tests = shouldTest ? testPaths : [];
          return testRunner.runTests(tests);
        });
      })
      .then(runResults => {
        if (argv.json) {
          process.stdout.write(JSON.stringify(formatTestResults(runResults)));
        }
        return runResults;
      })
      .then(runResults => onComplete && onComplete(runResults.success))
      .catch(error => {
        console.error('Failed with unexpected error.');
        process.nextTick(() => {
          throw error;
        });
      });
  }

  if (argv.watch !== undefined) {
    getWatcher(argv, packageRoot, watcher => {
      let tid;
      watcher.on('all', (_, filePath) => {
        if (tid) {
          clearTimeout(tid);
          tid = null;
        }
        tid = setTimeout(() => {
          _runCLI(filePath);
        }, WATCHER_DEBOUNCE);
      });
      if (argv.watch !== 'skip') {
        _runCLI();
      }
    });
  } else {
    _runCLI();
  }
}

exports.TestRunner = TestRunner;
exports.getVersion = getVersion;
exports.runCLI = runCLI;
