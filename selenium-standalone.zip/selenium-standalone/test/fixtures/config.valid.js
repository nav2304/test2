module.exports = {
  version: "42",
  drivers: {
    ie: {
      version: 42,
      baseURL: 'http://www.google.fr',
    }
  }
};
