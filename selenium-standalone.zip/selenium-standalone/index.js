module.exports = {
  install: require('./lib/install'),
  start: require('./lib/start')
};
