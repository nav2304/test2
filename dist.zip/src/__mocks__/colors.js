'use strict';

module.exports = {
  supportsColor: {}
};
