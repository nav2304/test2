'use strict';

module.exports = {

  post: jest.genMockFunction()

};
