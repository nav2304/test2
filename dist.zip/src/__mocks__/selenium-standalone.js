'use strict';

module.exports = {
  install: jest.genMockFunction(),
  start: jest.genMockFunction()
};

