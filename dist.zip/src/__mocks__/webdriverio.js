'use strict';

module.exports = {
  remote: jest.genMockFunction()
};
