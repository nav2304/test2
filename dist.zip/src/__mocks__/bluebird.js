'use strict';

jest.autoMockOff();
module.exports = require.requireActual('bluebird');
jest.autoMockOn();
