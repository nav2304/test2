'use strict';

module.exports = {
  wrapAsyncObject: jest.genMockFunction()
};
