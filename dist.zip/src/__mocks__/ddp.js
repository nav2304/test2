'use strict';

module.exports = jest.genMockFn();
